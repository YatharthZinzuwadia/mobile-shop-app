import { registerRootComponent } from "expo";
import App from "./App";

// This ensures the app works with Expo Go and native builds
registerRootComponent(App);
